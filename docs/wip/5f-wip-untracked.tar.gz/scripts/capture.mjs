// Headless capture over the Chrome DevTools protocol.
// Usage: node scripts/capture.mjs <outDir> <name>=<query>[@frames] ...
// Each capture is the 1080×1080 page (canvas shown 1:1 at 1080). With @N it also writes N frames at ~30fps.
import { spawn } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const [outDir, ...jobs] = process.argv.slice(2);
const base = process.env.BASE ?? 'http://127.0.0.1:4173/';
const port = 9333;
mkdirSync(outDir, { recursive: true });
const chrome = spawn(
  '/usr/bin/google-chrome',
  [
    '--headless=new',
    '--no-sandbox',
    '--use-angle=swiftshader',
    '--enable-unsafe-swiftshader',
    '--hide-scrollbars',
    `--user-data-dir=${join(outDir, '.chrome')}`,
    `--remote-debugging-port=${port}`,
    '--window-size=1080,1080',
    'about:blank',
  ],
  { stdio: 'ignore' },
);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let target;
for (let i = 0; i < 60 && !target; i++) {
  await sleep(250);
  try {
    const list = await (await fetch(`http://127.0.0.1:${port}/json`)).json();
    target = list.find((t) => t.type === 'page');
  } catch {}
}
if (!target) throw new Error('chrome did not start');
const ws = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((r) => ws.addEventListener('open', r));
let id = 0;
const pending = new Map();
ws.addEventListener('message', (e) => {
  const msg = JSON.parse(e.data);
  if (msg.id && pending.has(msg.id)) {
    pending.get(msg.id)(msg);
    pending.delete(msg.id);
  }
});
const send = (method, params = {}) =>
  new Promise((r) => {
    id += 1;
    pending.set(id, r);
    ws.send(JSON.stringify({ id, method, params }));
  });
await send('Emulation.setDeviceMetricsOverride', { width: 1080, height: 1080, deviceScaleFactor: 1, mobile: false });
const shot = async (file) => {
  const res = await send('Page.captureScreenshot', { format: 'png', clip: { x: 0, y: 0, width: 1080, height: 1080, scale: 1 } });
  writeFileSync(file, Buffer.from(res.result.data, 'base64'));
};
for (const job of jobs) {
  const cut = job.indexOf('=');
  const name = job.slice(0, cut);
  const rest = job.slice(cut + 1);
  const [query, framesStr] = rest.split('@');
  await send('Page.navigate', { url: query.startsWith('/') ? `${base.replace(/\/$/, '')}${query}` : `${base}?${query}` });
  await sleep(3500);
  await shot(join(outDir, `${name}.png`));
  const info = await send('Runtime.evaluate', { expression: 'JSON.stringify(window.__tower ?? null)', returnByValue: true });
  writeFileSync(join(outDir, `${name}.json`), info.result?.result?.value ?? 'null');
  const frames = Number(framesStr ?? 0);
  if (frames > 0) {
    mkdirSync(join(outDir, `${name}-frames`), { recursive: true });
    for (let f = 0; f < frames; f++) {
      await shot(join(outDir, `${name}-frames`, `${String(f).padStart(4, '0')}.png`));
      await sleep(33);
    }
  }
  console.log('captured', name);
}
ws.close();
chrome.kill();
process.exit(0);
