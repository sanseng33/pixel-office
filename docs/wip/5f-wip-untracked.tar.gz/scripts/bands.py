# Per-floor pixel stats from a capture + its __tower JSON: bright (furniture/people) pixel share in each floor's band.
import json, sys
from PIL import Image

for name in sys.argv[2:]:
    img = Image.open(f"{sys.argv[1]}/{name}.png").convert("RGB")
    info = json.load(open(f"{sys.argv[1]}/{name}.json"))
    s = img.width / 540
    print(name, img.size, "grid", info["gridN"], "tiles", info["tiles"])
    for f in info["floors"]:
        box = [int(f["minX"] * s), int(f["minY"] * s), int(f["maxX"] * s), int(f["maxY"] * s)]
        c = img.crop(box)
        px = list(c.getdata())
        bright = sum(1 for r, g, b in px if r + g + b > 300)
        print(f"  {f['level']}F box={box} bright={bright} share={bright / max(1, len(px)):.4f}")
